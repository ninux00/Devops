#!/bin/bash

# user-data-dm-ws.sh

cd
mkdir .archive
echo "install nvm"
wget https://raw.githubusercontent.com/creationix/nvm/v0.32.0/install.sh
chmod +x install.sh
./install.sh
mv install.sh .archive/install.sh.nvm
. ~/.nvm/nvm.sh

#echo "install nodejs 6.10"
#nvm install 6.10

echo "install c9"
wget https://raw.githubusercontent.com/c9/install/master/install.sh
chmod +x install.sh
./install.sh
mv install.sh .archive/install.sh.c9

echo "install c9sdk"
git clone https://github.com/c9/core.git c9sdk
cd c9sdk
./scripts/install-sdk.sh

exit 0
